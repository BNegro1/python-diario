module.exports = {
  hooks: [],
  port: 3000,
};
